package es.unican.is2.FranquiciasUCCommon;

@SuppressWarnings("serial")
public class NombreVacio extends Exception {

}
